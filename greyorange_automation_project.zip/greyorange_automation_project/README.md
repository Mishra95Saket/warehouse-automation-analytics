# GreyOrange Warehouse Automation Project

This repository contains an end‑to‑end data analysis project that
simulates and evaluates warehouse automation deployments using
GreyOrange’s tote‑to‑person technology.  GreyOrange solutions use
Vertical Tote Movers (VTMs) and Horizontal Tote Movers (HTMs) to
optimize space and throughput【628455820589393†L112-L117】, transferring totes within aisles and
from cantilevers to stations【628455820589393†L147-L156】.  These robots work in tandem to
deliver high throughput (up to 400 tote presentations per station per
hour) and scalable automation【628455820589393†L166-L173】.  The synthetic dataset and
analysis provided here enable exploration of how different robot mixes,
site characteristics and tool choices affect installation cost, project
duration and commissioning time.

## Data Source and Simulation

The dataset used in this project is generated using the
`generate_robotics_dataset.py` script in the `src/` directory.  The
generator draws on publicly available information about GreyOrange
technology to define realistic parameter ranges and relationships:

- **VTMs and HTMs** – GreyOrange’s tote‑to‑person solutions allow
  simultaneous use of VTMs and HTMs to increase performance and speed
  and maximize vertical space utilization【628455820589393†L112-L117】.  VTMs transfer totes
  within aisles and rearrange them within a storage bay based on
  popularity while HTMs transfer totes from cantilevers to stations at
  approximately 13 ft/s and auto‑lift totes for improved operator
  ergonomics【628455820589393†L147-L156】.
- **High throughput & rapid deployment** – Relay Pick, an AI‑driven
  GreyOrange solution, supports up to five‑deep storage while
  delivering hundreds of tote presentations per hour.  Its modular
  design enables installations to go live in under nine months
 【628455820589393†L166-L173】.  Our generator scales project durations and costs based on
  robot counts, warehouse area and tool usage to reflect these
  efficiencies.

The resulting CSV file (`data/robotics_generated.csv`) contains one
record per project with the following fields:

- `project_id` – Unique identifier.
- `region` – Geographic region of the site (North America, Europe,
  Asia‑Pacific, Latin America, Middle East & Africa).
- `warehouse_area_sqft` – Size of the warehouse in square feet.
- `count_vtm` / `count_htm` / `total_robots` – Numbers of vertical and
  horizontal tote movers deployed.
- `robot_mix` – Categorical variable indicating whether the project is
  VTM‑dominated, HTM‑dominated or Mixed.
- `team_size` – Size of the deployment team.
- `uses_vos` / `uses_cad` – Flags indicating whether Visual Operating
  System (VOS) and Computer‑Aided Design tools were used.  VOS and CAD
  usage typically reduces commissioning time.
- `towers_count`, `servers_installed`, `stations_installed`,
  `assemblies`, `hardware_tools_count` – Additional project features
  capturing vertical infrastructure, compute requirements, workstation
  counts, mechanical assemblies and the complexity of hardware tools.
- `installation_cost_musd` – Total project cost in millions of USD.
- `project_duration_days` – Number of days to complete installation.
- `commissioning_days` – Days required to commission and hand over the
  system after installation.
- `success_rating` – A score (1–5) computed from cost and duration
  relative to the best performing projects.

All values are synthetic and do not represent any proprietary
information.  The distributions and relationships are designed to be
realistic; for example, more VTMs and larger vertical towers increase
project duration, while using VOS and CAD reduces commissioning time.

## Business Questions

The analysis addresses four key questions relevant to a senior
Automation Project Engineer:

1. **What factors most strongly influence project duration?**
   A multiple linear regression model quantifies the impact of robot
   counts, warehouse size, team size, tool usage and towers on the
   number of days required to complete installation.
2. **How does robot mix (HTM vs VTM) affect installation cost and
   duration?**  Average costs and durations are compared across
   VTM‑dominated, HTM‑dominated and mixed deployments to understand the
   trade‑offs associated with each configuration.
3. **Do advanced tools like VOS and CAD reduce commissioning time?**
   Commissioning days are compared between projects that used these
   tools and those that did not, and statistical tests are performed to
   assess significance.
4. **Which regions incur the highest costs and longest durations?**
   Regional summaries help identify markets where projects tend to be
   more expensive or time‑consuming, informing resource allocation and
   pricing strategies.

The analysis script prints results to the console and writes detailed
tables into an Excel file (`results/summary.xlsx`) for further review.

## Setup and Execution

1. **Clone the repository**

   ```bash
   git clone <your_repository_url>
   cd greyorange_automation_project
   ```

2. **Install dependencies**.  Create a Conda or virtual environment
   using the provided `environment.yml` or `requirements.txt`:

   Using conda:

   ```bash
   conda env create -f environment.yml
   conda activate greyorange-automation
   ```

   Or using pip:

   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Generate the dataset**:

   ```bash
   python src/generate_robotics_dataset.py \
       --n_projects 300 \
       --seed 42 \
       --output data/robotics_generated.csv
   ```

   Adjust the number of projects or seed as desired.  The script
   creates a CSV file in the `data/` directory.

4. **Run the analysis**:

   ```bash
   python src/analysis_robotics.py \
       --input data/robotics_generated.csv \
       --output results/summary.xlsx
   ```

   This prints model coefficients and summary statistics and saves
   Excel sheets to the `results/` directory.  An additional file,
   `tools_and_resources.xlsx`, lists common tools (VOS, tower,
   CAD, hardware tools, servers, stations and assemblies) alongside
   descriptions and robot types.

## Example Results

Running the analysis on a dataset of 250 simulated projects yielded the
following insights:

- **Duration drivers** – Towers count, robot mix and server count were
  the strongest predictors of project duration.  Additional towers add
  ~2.7 days to the timeline and mixed robot deployments add ~1.5 days.
  The regression model explained roughly 80 % of the variation in
  project duration (R²≈0.80).
- **Robot mix comparison** – Mixed projects had the highest average
  installation cost (≈ $3.55 M) and longest duration (~61 days),
  followed closely by VTM‑dominated projects.  HTM‑dominated sites were
  cheaper and faster on average.
- **Tool effectiveness** – Projects using VOS and CAD completed
  commissioning 3–4 days sooner on average.  Welch’s t‑tests showed
  that these reductions were statistically significant (*p* < 0.05).
- **Regional variation** – Latin American sites exhibited the highest
  installation costs and commissioning durations, while projects in
  North America and Asia‑Pacific were slightly cheaper and faster.

These findings suggest that careful planning of vertical infrastructure
and robot mix, along with adoption of advanced digital tools, can
significantly improve project outcomes.

## Tools and Resources

The `results/tools_and_resources.xlsx` workbook contains two sheets:

1. **Tools** – Descriptions of common tools and equipment used during
   warehouse automation projects, including GreyOrange’s Visual
   Operating System (VOS), structural towers, CAD software, hardware
   tools, on‑site servers, operator stations and mechanical
   assemblies.
2. **Robot Types** – A summary of the roles of VTMs and HTMs.  VTMs
   handle vertical tote movement and rearrangement within aisles,
   while HTMs ferry totes from cantilevers to stations at high speed
   and provide ergonomic lifting【628455820589393†L147-L156】.

These resources serve as a reference for deployment engineers
planning GreyOrange‑style projects.

## Suggested Next Steps

1. **Enhance modelling** – Experiment with non‑linear regression
   techniques (e.g., random forests or gradient boosting) to capture
   complex interactions between robots, area and tools.
2. **Integrate real data** – When available, incorporate actual
   project data to validate and refine the synthetic models.  This could
   include throughput metrics, operator training times or
   maintenance costs.
3. **Develop a dashboard** – Build an interactive dashboard (e.g.,
   using Streamlit or Dash) to visualise project performance by
   region, robot mix and tool usage for rapid stakeholder insights.
4. **Simulate dynamic scenarios** – Extend the generator to simulate
   phased deployments, scaling strategies and failure modes, or to
   model how upgrades (e.g., additional HTMs) influence ROI over time.

## License and Acknowledgements

This project is provided for educational purposes only.  It is not
affiliated with GreyOrange.  The descriptions of GreyOrange
technologies are derived from publicly available information about
their tote‑to‑person automation solutions【628455820589393†L112-L117】【628455820589393†L147-L156】.