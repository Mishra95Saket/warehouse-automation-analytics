"""
generate_robotics_dataset
=========================

This module provides functionality to generate a synthetic dataset for
robotics automation projects inspired by GreyOrange's warehouse
automation solutions.  It simulates the deployment of vertical tote
movers (VTMs) and horizontal tote movers (HTMs) in distribution
centers, capturing key metrics such as warehouse size, number of robots,
project duration, installation costs, team size, commissioning time,
and success rating.  The generated dataset does not contain any
proprietary data; instead, it is created using statistical
distributions and deterministic rules based on publicly available
information about GreyOrange technologies【628455820589393†L112-L117】【628455820589393†L147-L156】.

The dataset can be used to explore questions such as how robot mix and
warehouse size affect installation timelines, whether using advanced
tools like VOS and CAD shortens commissioning, and which regions incur
higher costs.

Usage example::

    from generate_robotics_dataset import generate_robotics_dataset
    df = generate_robotics_dataset(n_projects=200, seed=42,
                                   output_path="../data/robotics_generated.csv")

"""

from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional


def generate_robotics_dataset(
    n_projects: int = 250,
    seed: Optional[int] = None,
    output_path: Optional[str] = None,
) -> pd.DataFrame:
    """Generate a synthetic robotics automation dataset.

    Parameters
    ----------
    n_projects : int, default=250
        Number of project records to simulate.
    seed : int, optional
        Random seed for reproducibility.
    output_path : str, optional
        If provided, save the generated data to this CSV path.

    Returns
    -------
    pandas.DataFrame
        DataFrame containing simulated project metrics.
    """
    rng = np.random.default_rng(seed)

    # Project identifiers
    project_id = np.arange(1, n_projects + 1)

    # Regions with probabilities roughly reflecting global distribution of supply chain hubs
    regions = [
        "North America",
        "Europe",
        "Asia-Pacific",
        "Latin America",
        "Middle East & Africa",
    ]
    region_probs = [0.35, 0.25, 0.25, 0.10, 0.05]
    region = rng.choice(regions, size=n_projects, p=region_probs)

    # Warehouse area in square feet: between 5k and 150k with a log-normal like distribution
    # Generate log-normal values then scale to the range
    area = np.exp(rng.normal(loc=10.5, scale=0.5, size=n_projects))  # log-norm approx
    area = 5000 + (area - area.min()) / (area.max() - area.min()) * (150000 - 5000)
    area = area.astype(float)

    # Number of vertical and horizontal tote movers
    count_vtm = rng.integers(low=5, high=25, size=n_projects)
    count_htm = rng.integers(low=5, high=25, size=n_projects)

    total_robots = count_vtm + count_htm

    # Robot mix category for convenience: 'HTM', 'VTM' or 'Mixed'
    robot_mix = np.where(
        count_htm > 1.5 * count_vtm,
        "HTM-dominated",
        np.where(count_vtm > 1.5 * count_htm, "VTM-dominated", "Mixed")
    )

    # Team size: more robots and larger area require larger teams (5 to 40)
    team_size = rng.integers(low=5, high=40, size=n_projects) + (total_robots // 20)
    team_size = np.clip(team_size, 5, 50)

    # Tools usage flags: VOS and CAD used widely, hardware tools always needed
    uses_vos = rng.choice([0, 1], size=n_projects, p=[0.2, 0.8])
    uses_cad = rng.choice([0, 1], size=n_projects, p=[0.15, 0.85])

    # Towers installed (0-3) depending on vertical storage height; more VTMs may require towers
    towers_count = (count_vtm // 10) + rng.integers(0, 2, size=n_projects)
    towers_count = np.clip(towers_count, 0, 5)

    # Servers and stations installed; stations roughly scale with robots
    servers_installed = rng.integers(low=1, high=4, size=n_projects)
    stations_installed = rng.integers(low=2, high=8, size=n_projects) + (total_robots // 30)
    stations_installed = np.clip(stations_installed, 2, 10)

    # Assemblies per station (1-3) plus noise
    assemblies_per_station = rng.integers(low=1, high=4, size=n_projects)
    assemblies = stations_installed * assemblies_per_station

    # Hardware tools count (proxy for complexity) between 10 and 30
    hardware_tools_count = rng.integers(low=10, high=30, size=n_projects)

    # Installation cost: base + cost per robot + cost per square foot + premium for VTM (vertical complexity)
    cost_base = 1.5  # millions USD
    cost_per_robot = 0.05  # million per robot
    cost_per_sqft = 0.000005  # million per sq ft
    vtm_premium = 0.02  # million per VTM unit
    cost = (
        cost_base
        + cost_per_robot * total_robots
        + cost_per_sqft * area
        + vtm_premium * count_vtm
    )
    # Add random noise (±10%)
    cost *= rng.normal(loc=1.0, scale=0.1, size=n_projects)
    cost = np.round(cost, 3)  # million USD

    # Project duration (days): base + scaling with robots and area - reduction with team_size and tool usage
    duration_base = 60  # days
    duration = (
        duration_base
        + 0.5 * total_robots
        + 0.0002 * area
        - 0.8 * team_size
        - 5 * uses_vos  # VOS reduces time by 5 days
        - 3 * uses_cad  # CAD reduces by 3 days
    )
    # Additional time if high towers count due to vertical complexity
    duration += 2 * towers_count
    # Noise
    duration += rng.normal(loc=0.0, scale=5.0, size=n_projects)
    duration = np.clip(duration, 30, None).round().astype(int)

    # Commissioning days: subset of duration; depends on robot type mix and tool usage
    commissioning = (
        0.3 * duration
        + 0.8 * count_vtm
        + 0.5 * count_htm
        - 2 * uses_vos
        - 1 * uses_cad
        + rng.normal(loc=0.0, scale=3.0, size=n_projects)
    )
    commissioning = np.clip(commissioning, 10, None).round().astype(int)

    # Success rating (1-5): high when projects finish on time and cost under budget
    # We create an ideal benchmark based on predicted duration and cost; lower cost and shorter duration yield higher scores
    max_cost = cost.max()
    min_cost = cost.min()
    max_duration = duration.max()
    min_duration = duration.min()
    cost_score = 1 - (cost - min_cost) / (max_cost - min_cost + 1e-8)
    duration_score = 1 - (duration - min_duration) / (max_duration - min_duration + 1e-8)
    success_raw = 2.5 * cost_score + 2.5 * duration_score
    success_rating = np.round(1 + 4 * (success_raw / success_raw.max())).astype(int)
    success_rating = np.clip(success_rating, 1, 5)

    df = pd.DataFrame({
        "project_id": project_id,
        "region": region,
        "warehouse_area_sqft": area.round().astype(int),
        "count_vtm": count_vtm,
        "count_htm": count_htm,
        "total_robots": total_robots,
        "robot_mix": robot_mix,
        "team_size": team_size,
        "uses_vos": uses_vos,
        "uses_cad": uses_cad,
        "towers_count": towers_count,
        "servers_installed": servers_installed,
        "stations_installed": stations_installed,
        "assemblies": assemblies,
        "hardware_tools_count": hardware_tools_count,
        "installation_cost_musd": cost,
        "project_duration_days": duration,
        "commissioning_days": commissioning,
        "success_rating": success_rating,
    })

    if output_path:
        df.to_csv(output_path, index=False)

    return df


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generate synthetic robotics automation project data")
    parser.add_argument("--n_projects", type=int, default=250, help="Number of projects to generate")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    parser.add_argument("--output", type=str, default="../data/robotics_generated.csv", help="Output CSV file path")
    args = parser.parse_args()
    generate_robotics_dataset(n_projects=args.n_projects, seed=args.seed, output_path=args.output)