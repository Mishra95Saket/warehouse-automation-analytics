"""
analysis_robotics
=================

This script performs exploratory data analysis (EDA) and basic modelling
on a synthetic dataset of warehouse automation projects.  The data
captures information about warehouse area, robot counts, robot mix,
tool usage, team sizes, project durations, costs and commissioning
times.  The analysis addresses several business questions relevant to
automation project engineers:

1. **What factors most strongly influence project duration?**  A linear
   regression model is fit to assess the impact of robots, warehouse
   size, team size, tool usage and towers on the number of days to
   complete the project.
2. **How does robot mix (HTM vs VTM) affect installation cost and
   duration?**  Average costs and durations are compared across
   robot_mix categories.
3. **Do advanced tools (VOS and CAD) reduce commissioning time?**
   Mean commissioning days are computed by tool usage and statistical
   tests (Welch’s t‑test) are applied.
4. **Which regions incur the highest costs and longest durations?**
   Regional averages are summarised and exported to an Excel file along
   with overall descriptive statistics.

The results are printed to the console and saved into an Excel summary
file (``results/summary.xlsx``).  Plots can also be generated but are
optional due to runtime environment constraints.

Usage
-----

```
python src/analysis_robotics.py --input data/robotics_generated.csv --output results/summary.xlsx
```
"""

from __future__ import annotations

import argparse
import os
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import r2_score
from scipy import stats


def load_data(path: str) -> pd.DataFrame:
    """Load the robotics dataset from a CSV file."""
    return pd.read_csv(path)


def preprocess_for_duration(df: pd.DataFrame):
    """Prepare feature matrix and target for duration modelling."""
    X = df.drop(columns=["project_duration_days", "installation_cost_musd", "commissioning_days", "success_rating", "project_id"])
    y = df["project_duration_days"].values
    # Identify numeric and categorical columns
    numeric_cols = [
        "warehouse_area_sqft", "count_vtm", "count_htm", "total_robots",
        "team_size", "towers_count", "servers_installed", "stations_installed",
        "assemblies", "hardware_tools_count", "installation_cost_musd", "commissioning_days"
    ]
    # Some numeric cols may not exist depending on dataset; guard
    numeric_cols = [col for col in numeric_cols if col in X.columns]
    categorical_cols = [col for col in X.columns if col not in numeric_cols]
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", "passthrough", numeric_cols),
            ("cat", OneHotEncoder(drop="first"), categorical_cols),
        ]
    )
    X_transformed = preprocessor.fit_transform(X)
    return preprocessor, X_transformed, y


def fit_duration_model(X: np.ndarray, y: np.ndarray) -> LinearRegression:
    model = LinearRegression()
    model.fit(X, y)
    return model


def extract_coefficients(model: LinearRegression, preprocessor: ColumnTransformer) -> pd.Series:
    # Get feature names
    numeric_features = preprocessor.transformers_[0][2]
    cat_encoder: OneHotEncoder = preprocessor.transformers_[1][1]
    cat_features = cat_encoder.get_feature_names_out(preprocessor.transformers_[1][2])
    feature_names = list(numeric_features) + list(cat_features)
    return pd.Series(model.coef_, index=feature_names)


def compare_robot_mix(df: pd.DataFrame) -> pd.DataFrame:
    """Compute average installation cost and duration by robot mix."""
    return df.groupby("robot_mix")[["installation_cost_musd", "project_duration_days"]].mean().sort_values(by="installation_cost_musd", ascending=False)


def compare_tool_usage(df: pd.DataFrame) -> pd.DataFrame:
    """Compare commissioning days by VOS and CAD usage."""
    # Means and t-tests
    results = []
    for tool in ["uses_vos", "uses_cad"]:
        group1 = df[df[tool] == 1]["commissioning_days"]
        group0 = df[df[tool] == 0]["commissioning_days"]
        mean1 = group1.mean()
        mean0 = group0.mean()
        t_stat, p_val = stats.ttest_ind(group1, group0, equal_var=False)
        results.append({
            "tool": tool,
            "mean_when_used": mean1,
            "mean_when_not_used": mean0,
            "p_value": p_val,
        })
    return pd.DataFrame(results)


def regional_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Summarise average cost and duration by region."""
    return df.groupby("region")[["installation_cost_musd", "project_duration_days", "commissioning_days"]].mean().sort_values(by="installation_cost_musd", ascending=False)


def save_summary_excel(dfs: dict[str, pd.DataFrame], output_path: str) -> None:
    """Save multiple DataFrames to an Excel file with separate sheets."""
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for sheet_name, data in dfs.items():
            data.to_excel(writer, sheet_name=sheet_name, index=True)


def main(input_csv: str, output_excel: str):
    df = load_data(input_csv)
    print(f"Loaded {len(df)} project records.")

    # Question 1: duration influences
    preprocessor, X, y = preprocess_for_duration(df)
    model = fit_duration_model(X, y)
    coeffs = extract_coefficients(model, preprocessor)
    r2 = r2_score(y, model.predict(X))
    print("\nLinear regression coefficients for project duration:")
    print(coeffs.sort_values(ascending=False).head(10))
    print(f"R-squared for duration model: {r2:.3f}\n")

    # Question 2: robot mix comparison
    mix_summary = compare_robot_mix(df)
    print("Average installation cost and duration by robot mix:\n", mix_summary, "\n")

    # Question 3: tool usage effect on commissioning
    tool_summary = compare_tool_usage(df)
    print("Effect of tool usage on commissioning days:\n", tool_summary, "\n")

    # Question 4: regional summary
    region_summary = regional_summary(df)
    print("Average cost and durations by region:\n", region_summary, "\n")

    # Save to Excel
    summary_data = {
        "robot_mix_summary": mix_summary,
        "tool_usage_effect": tool_summary,
        "regional_summary": region_summary,
        "duration_coefficients": coeffs.to_frame(name="coefficient"),
    }
    os.makedirs(os.path.dirname(output_excel), exist_ok=True)
    save_summary_excel(summary_data, output_excel)
    print(f"Summary saved to {output_excel}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyse robotics automation dataset")
    parser.add_argument("--input", type=str, default="../data/robotics_generated.csv", help="Input CSV file")
    parser.add_argument("--output", type=str, default="../results/summary.xlsx", help="Output Excel file path")
    args = parser.parse_args()
    main(args.input, args.output)